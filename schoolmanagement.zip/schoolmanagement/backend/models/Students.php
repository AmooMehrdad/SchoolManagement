<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%students}}".
 *
 * @property integer $student_id
 * @property integer $national_id
 * @property string $name
 * @property string $family
 * @property integer $father_name
 * @property string $address
 * @property integer $phone_number
 * @property integer $mobile_number
 * @property string $birthday
 * @property integer $class_id
 *
 * @property Classes $class
 */
class Students extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%students}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['student_id', 'national_id', 'name', 'family', 'father_name', 'address', 'phone_number', 'mobile_number', 'birthday', 'class_id'], 'required'],
            [['student_id', 'national_id', 'father_name', 'phone_number', 'mobile_number', 'class_id'], 'integer'],
            [['address'], 'string'],
            [['birthday'], 'safe'],
            [['name', 'family'], 'string', 'max' => 60],
            [['class_id'], 'exist', 'skipOnError' => true, 'targetClass' => Classes::className(), 'targetAttribute' => ['class_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'student_id' => 'Student ID',
            'national_id' => 'National ID',
            'name' => 'Name',
            'family' => 'Family',
            'father_name' => 'Father Name',
            'address' => 'Address',
            'phone_number' => 'Phone Number',
            'mobile_number' => 'Mobile Number',
            'birthday' => 'Birthday',
            'class_id' => 'Class ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClass()
    {
        return $this->hasOne(Classes::className(), ['id' => 'class_id']);
    }

    /**
     * @inheritdoc
     * @return StudentsQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new StudentsQuery(get_called_class());
    }
}
