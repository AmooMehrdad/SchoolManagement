<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%employees}}".
 *
 * @property integer $personnel_id
 * @property integer $national_id
 * @property string $name
 * @property string $family
 * @property string $father_name
 * @property string $address
 * @property string $birthday
 * @property integer $phone_number
 * @property integer $mobile_number
 * @property integer $post
 * @property string $startday
 * @property string $endday
 *
 * @property Posts $post
 */
class Employees extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%employees}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['personnel_id', 'national_id', 'name', 'family', 'father_name', 'address', 'birthday', 'phone_number', 'mobile_number'], 'required'],
            [['personnel_id', 'national_id', 'phone_number', 'mobile_number', 'post'], 'integer'],
            [['address'], 'string'],
            [['birthday', 'startday', 'endday'], 'safe'],
            [['name', 'family', 'father_name'], 'string', 'max' => 60],
            [['post'], 'exist', 'skipOnError' => true, 'targetClass' => Posts::className(), 'targetAttribute' => ['post' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'personnel_id' => 'Personnel ID',
            'national_id' => 'National ID',
            'name' => 'Name',
            'family' => 'Family',
            'father_name' => 'Father Name',
            'address' => 'Address',
            'birthday' => 'Birthday',
            'phone_number' => 'Phone Number',
            'mobile_number' => 'Mobile Number',
            'post' => 'Post',
            'startday' => 'Startday',
            'endday' => 'Endday',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPost()
    {
        return $this->hasOne(Posts::className(), ['id' => 'post']);
    }

    /**
     * @inheritdoc
     * @return EmployeesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new EmployeesQuery(get_called_class());
    }
}
