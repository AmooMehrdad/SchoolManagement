<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "{{%classes}}".
 *
 * @property integer $id
 * @property integer $grade_id
 *
 * @property Grades $grade
 * @property Students[] $students
 */
class Classes extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%classes}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'required'],
            [['id', 'grade_id'], 'integer'],
            [['grade_id'], 'exist', 'skipOnError' => true, 'targetClass' => Grades::className(), 'targetAttribute' => ['grade_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'grade_id' => 'Grade ID',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getGrade()
    {
        return $this->hasOne(Grades::className(), ['id' => 'grade_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStudents()
    {
        return $this->hasMany(Students::className(), ['class_id' => 'id']);
    }

    /**
     * @inheritdoc
     * @return ClassesQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new ClassesQuery(get_called_class());
    }
}
