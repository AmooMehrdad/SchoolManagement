<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "grades".
 *
 * @property integer $id
 * @property string $grade_name
 *
 * @property Classes[] $classes
 */
class Grades extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'grades';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['grade_name'], 'required'],
            [['id'], 'integer'],
            [['grade_name'], 'string', 'max' => 60],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'grade_name' => 'Grade Name',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getClasses()
    {
        return $this->hasMany(Classes::className(), ['grade_id' => 'id']);
    }
}
