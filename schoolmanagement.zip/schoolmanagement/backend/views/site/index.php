<?php

/* @var $this yii\web\View */


use yii\helpers\Url;


$this->title = 'داشبورد';
?>
<div class="site-index">

    <ul class="management-options">
        <li class="col-xs-12 col-sm-6 col-md-2">
            <a href="<?= Url::to(['posts/']); ?>">
                <img class="img-responsive mgmt-images" src="images/post_icon.png" />
                <span>Posts</span>
            </a>
        </li>
        <li class="col-xs-12 col-sm-6 col-md-2">
            <a href="<?= Url::to(['employees/']); ?>">
                <img class="img-responsive mgmt-images" src="images/employee_icon.png" />
                <span>Employees</span>
            </a>
        </li>
        <li class="col-xs-12 col-sm-6 col-md-2">
            <a href="<?= Url::to(['students/']); ?>">
            <img class="img-responsive mgmt-images" src="images/student_icon.svg" />
                <span>Students</span>
            </a>
        </li>
        <li class="col-xs-12 col-sm-6 col-md-2">
            <a href="<?= Url::to(['grades/']); ?>">
                <img class="img-responsive mgmt-images" src="images/grade_icon.jpg" />
                <span>Grades</span>
            </a>
        </li>
        <li class="col-xs-12 col-sm-6 col-md-2">
            <a href="<?= Url::to(['classes/']); ?>">
                <img class="img-responsive mgmt-images" src="images/class_icon.png" />
                <span>Classes</span>
            </a>
        </li>
        <li class="col-xs-12 col-sm-6 col-md-2">
            <a href="<?= Url::to(['help/']); ?>">
                <img class="img-responsive mgmt-images" src="images/help_icon.svg" />
                <span>Help</span>
            </a>
        </li>
    </ul>

</div>
